﻿namespace BorderControl
{
    public interface INamable
    {
        string Name { get; }
    }
}
